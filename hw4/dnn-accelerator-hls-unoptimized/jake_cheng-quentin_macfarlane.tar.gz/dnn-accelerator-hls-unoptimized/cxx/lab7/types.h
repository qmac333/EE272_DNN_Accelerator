//
// Copyright 2003-2019 Siemens
//
#ifndef _INCLUDED_TYPES_H_
#define _INCLUDED_TYPES_H_

struct addrData {
  uint6  addr;
  int    data;
};

#endif

