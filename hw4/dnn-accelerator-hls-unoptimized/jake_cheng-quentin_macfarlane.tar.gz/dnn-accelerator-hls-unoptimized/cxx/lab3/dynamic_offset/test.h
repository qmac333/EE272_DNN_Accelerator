#ifndef _INCLUDED_TEST_H_
#define _INCLUDED_TEST_H_

#include <ac_int.h>

void test_wrapper(int din[40],  uint6 offset,
          int dout[40]);

void test_orig_wrapper(int din[40],  uint6 offset,
               int dout[40]);

#endif

