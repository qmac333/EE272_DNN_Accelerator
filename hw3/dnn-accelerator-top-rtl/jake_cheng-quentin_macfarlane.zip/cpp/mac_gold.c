
int mac_gold(int a, int b, int c)
{
    return a*b + c;
}